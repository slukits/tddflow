def answer() -> bool:
    return False